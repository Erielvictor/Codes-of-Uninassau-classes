package pacotes;

public class SuperClasse {
    protected String nome;
    protected int idade;
    
    public SuperClasse(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
    }

    public String obterInformacao() {
        return "Nome: " + nome + ", Idade: " + idade;
    }
}