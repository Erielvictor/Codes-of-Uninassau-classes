package pacotes;

public class SubClasse1 extends SuperClasse {
    private String habilidadeEspecial;


    public SubClasse1(String nome, int idade, String habilidadeEspecial) {
        super(nome, idade);
        this.habilidadeEspecial = habilidadeEspecial;
    }

    @Override
    public String obterInformacao() {
        return super.obterInformacao() + ", Habilidade Especial: " + habilidadeEspecial;
    }
}

