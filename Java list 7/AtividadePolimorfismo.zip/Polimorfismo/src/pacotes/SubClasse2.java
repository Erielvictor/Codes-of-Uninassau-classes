package pacotes;

public class SubClasse2 extends SuperClasse {
    private String ocupacao;

    public SubClasse2(String nome, int idade, String ocupacao) {
        super(nome, idade);
        this.ocupacao = ocupacao;
    }
    
    @Override
    public String obterInformacao() {
        return super.obterInformacao() + ", Ocupação: " + ocupacao;
    }
}