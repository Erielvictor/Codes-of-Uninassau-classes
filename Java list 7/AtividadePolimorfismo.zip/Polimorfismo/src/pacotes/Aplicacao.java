package pacotes;

public class Aplicacao {
    public static void main(String[] args) {

        SuperClasse pessoa1 = new SuperClasse("João", 45);
        SubClasse1 pessoa2 = new SubClasse1("Maria", 30, "Pintura");
        SubClasse2 pessoa3 = new SubClasse2("Carlos", 28, "Engenheiro");


        System.out.println(pessoa1.obterInformacao());
        System.out.println(pessoa2.obterInformacao());
        System.out.println(pessoa3.obterInformacao());
    }
}
